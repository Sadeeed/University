/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee_lab11;

/**
 *
 * @author Saira Aslam
 */
  public class CommissionEmployee extends Employee 
  {
      private double grossSales; // gross weekly sales
      private double commissionRate; // commission percentage
   
      // five-argument constructor
     public CommissionEmployee(String first, String last, String ssn, double sales, double rate )
     {
        super(first, last, ssn);
        setGrossSales(sales);
        setCommissionRate( rate );
     } // end five-argument CommissionEmployee constructor
  
     // set commission rate
     public void setCommissionRate( double rate )
    {
       if ((commissionRate < 0.0)||(commissionRate >1.0))
          // throw new IllegalArgumentException("Commiion rate should be > 0.0 and <1.0");
       this.commissionRate = rate;
    } // end method setCommissionRate
  
     // return commission rate
     public double getCommissionRate()
     {
        return commissionRate;
     } // end method getCommissionRate
  
     // set gross sales amount
     public void setGrossSales( double sales )
     {
        if (grossSales < 0.0)
           throw new IllegalArgumentException("Gross sales should be >= 0.0");
       this.grossSales = sales;
     } // end method setGrossSales
  
     // return gross sales amount
     public double getGrossSales()
     {
        return grossSales;
     } // end method getGrossSales
  
     // calculate earnings; override abstract method earnings in Employee
     public double earnings()
     {
        return getCommissionRate() * getGrossSales();
     } // end method earnings
  
     // return String representation of CommissionEmployee object
     public String toString()
     {
        return String.format( "%s: %s\n%s: $%,.2f; %s: %.2f", 
           "commission employee", super.toString(), 
           "gross sales", getGrossSales(), 
           "commission rate", getCommissionRate() );
     } // end method toString
  } // end class CommissionEmployee
