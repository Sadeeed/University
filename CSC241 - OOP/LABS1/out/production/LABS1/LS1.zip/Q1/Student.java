package Q1;

public class Student {
    private String id;
    private String name;
    private int date_of_birth;
    private String address;

    public Student(String i, String n, int d, String a)
    {
        id = i;
        name = n;
        date_of_birth = d;
        address = a;
    }

    public int CalculateAge(int dob)
    {
        return dob;
    }

    public void DisplayStudent()
    {
        System.out.println("Name: " + name + "\nID: " + id + "\nDOB: " + date_of_birth + "\nAddress: " + address);
    }

}
